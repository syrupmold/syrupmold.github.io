# shelter-editor
Fallout Shelter - Save Editor

Using the decryptor from http://fossd.bitballoon.com/

Live demo (Rakion99 Branch): https://rakion99.github.io/shelter-editor/
